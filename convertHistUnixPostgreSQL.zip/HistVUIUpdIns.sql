-- updates and inserts from HistVtmp to HistV

select 'deleting update records:' as msg,now() as curr_date_time 
;

delete from histv where exists
  (select * from histvui
   where histv.secid = histvui.secid
   and   histv.effdt = histvui.effdt)
;
select 'deleting update records:' as msg,now() as curr_date_time 
;
insert into histv 
select *
from histvui
;
truncate table embs_owner.histvui;


select 'done with update and insert:' as msg,now() as curr_date_time 
;