CREATE UNIQUE INDEX histvndx ON embs_owner.histv (secid, effdt)
;
