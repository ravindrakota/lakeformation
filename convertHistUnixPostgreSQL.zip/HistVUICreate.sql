DROP TABLE IF EXISTS histvui
;
CREATE TABLE  histvui 
as SELECT * 
FROM embs_owner.histv
WHERE 1=2
;


