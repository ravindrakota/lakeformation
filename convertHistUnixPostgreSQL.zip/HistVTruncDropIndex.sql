truncate table embs_owner.histv
;

DROP INDEX IF EXISTS histvndx
;
