truncate table embs_owner.histvui
;
