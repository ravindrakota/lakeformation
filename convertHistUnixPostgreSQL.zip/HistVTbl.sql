-- Vertical (3rd-Normal-Form) version of the Hist table, with one row per month
-- Effective date must contain the month, instead of 01
-- This differs from Hist which always had 01 (January) for the month, since it had one row per year

drop TABLE if exists histv;

CREATE TABLE histv (
	secid    int        NOT NULL,
        cusip    char(9)    NOT NULL,
	effdt    date       NOT NULL,
	fctr     float      NOT NULL,
	fctrsrc  char(4)    NOT NULL,
	cprm     real       NOT NULL,
	wac      real       NOT NULL,
        wacsrc   char(2)    NOT NULL,
	wam      smallint   NOT NULL,
        wamsrc   char(2)    NOT NULL,
	wala     smallint   NOT NULL,
        walasrc  char(2)    NOT NULL
)
;
