use embs
go
create index TrancheStructNdx  on TrancheStruct(SecId)
go
create index TrancheStructNdx2 on TrancheStruct(Cusip)
go
create index TrancheStructNdx3 on TrancheStruct(SecMnem)
go
