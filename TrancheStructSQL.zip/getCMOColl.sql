/*
      Purpose: This stored procedure gets collateral data from IssColl 
               for the tranche group of an inputted CMO tranche

      Input:   Cusip for the tranche

      Syntax:  exec getCMOColl  Cusip

      Example: exec getCMOColl '31396YCX8'
*/

use embs
go
drop   procedure getCMOColl
go
create procedure getCMOColl  @Cusip varchar(9)
as
declare @SecMnem varchar(20)
declare @IssueMnem varchar(20)
select @IssueMnem = '#'
declare @CollGroup varchar(10)
select 
     @IssueMnem = CASE WHEN (SecMnem like 'FHLMC.%') THEN 
                     substring(SecMnem,1,patindex('%-%',secmnem)-1)
                  WHEN (SecMnem like 'FNMA.%' or SecMnem like 'GNMA.%') THEN
                     /* start search for "-" with 11th character to ignore first dash, e.g. FNMA.1999-C01-A1 */
                     substring(SecMnem,1,charindex('-',secmnem,11)-1)
                  ELSE SecMnem
                  END,
     @CollGroup  = TRANCHE_GROUP,
     @SecMnem    = SecMnem
from TrancheStruct
where Cusip = @Cusip

if @IssueMnem = '#'
   begin
   select 
     @IssueMnem = CASE WHEN (SecMnem like 'FHLMC.%') THEN 
                     substring(SecMnem,1,patindex('%-%',secmnem)-1)
                  WHEN (SecMnem like 'FNMA.%' or SecMnem like 'GNMA.%') THEN
                     /* start search for "-" with 11th character to ignore first dash, e.g. FNMA.1999-C01-A1 */
                     substring(SecMnem,1,charindex('-',secmnem,11)-1)
                  ELSE SecMnem
                  END,
     @CollGroup  = 1,
     @SecMnem    = SecMnem
   from Sec
   where Cusip = @Cusip
   AND (SecMnem like 'FNMA.SMBS%' OR SecMnem like 'FHLMC.STR%')
   end

if @IssueMnem != '#' 
   begin
      if (select count(*) from IssColl where IssueMnem=@IssueMnem and ((CollGroup=@CollGroup) OR (collgroup like RTrim(@CollGroup)+Convert(char(7),'[A-Z]%')))) >= 1
          begin
             select IssueMnem,IssueCusip,CollGroup,SecMnem,SecCusip,OrigFace,RPB,WholePoolFlag,
                    Wac,Wam,Wala,IssueType
             from IssColl 
             where IssueMnem=@IssueMnem and ((CollGroup=@CollGroup) OR (collgroup like RTrim(@CollGroup)+Convert(char(7),'[A-Z]%')))
             order by SecMnem
          end
      else
          begin
             select 'No collateral data available for SecMnem:'+@SecMnem+'  IssueMnem:'+rtrim(@IssueMnem)+'  CollGroup:'+str(@CollGroup,8)
          end
   end
else
   begin
      select 'No structuring data available for this CUSIP'
   end
go
grant execute on getCMOColl to public
go
