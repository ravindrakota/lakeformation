use embs
go
truncate table TrancheStruct
go
drop index TrancheStruct.TrancheStructNdx
go
drop index TrancheStruct.TrancheStructNdx2
go
drop index TrancheStruct.TrancheStructNdx3
go
