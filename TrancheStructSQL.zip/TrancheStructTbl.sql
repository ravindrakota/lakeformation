use embs
go
drop table TrancheStruct
go
create table TrancheStruct (
SecId				int,
SecMnem				char(20),
TRANCHE_NUMBER			smallint,
NUMBER_OF_COMPONENTS		smallint,
COMPONENT_OF_TRANCHES		smallint,
TRANCHE_NAME			char(20),
TRANCHE_PRINCIPAL_DESCRIPTION	varchar(25),
TRANCHE_INTEREST_DESCRIPTION	varchar(25),
TRANCHE_OTHER_DESCRIPTION	varchar(25),
CUSIP				char(9),      /* 10 */
TRANCHE_FACE_AMOUNT		float,
INTEREST_TYPE			varchar(20),
COUPON_RATE			float,
ACCRUAL_RATE			float,
TREASURY_MATURITY		smallint,
TREASURY_YIELD			float,
TREASURY_SPREAD			float,
TRANCHE_YIELD			float,
TRANCHE_PRICE			float,
TRANCHE_PROCEEDS_WITH_INTEREST	float,      /* 20 */
TRANCHE_AVG_LIFE		float,
TRANCHE_DURATION		float,
TRANCHE_DATED_DATE		datetime,
TRANCHE_FIRST_PAYMENT_DATE	datetime,
TRANCHE_LAST_PAYMENT_DATE	datetime,
TRANCHE_FINAL_MATURITY_DATE     datetime,
DELAY_DAYS			smallint,
INTEREST_PAYMENT_FREQ		smallint,
PRINCIPAL_PAYMENT_FREQ		smallint,
STRUCT_LOW_PAC_BAND		float,     /* 30 */
STRUCT_HIGH_PAC_BAND		float,
FLOATER_INDEX			char(40),
INITIAL_INDEX_VALUE		float,
FLOATER_SPREAD			float,
FLOATER_MULTIPLIER		float,
FLOATER_CAP			float,
FLOATER_FLOOR			float,
FLOATER_INITIAL_COUPON		float,
FLOATER_RESET_FREQ		smallint,
FLOATER_FIRST_RESET_DATE	char(8),   /* 40 */
TRANCHE_GROUP			smallint,
TRANCHE_TYPE			char(12),
MACR                            char(3),
MIN_DENOM_AMT                   real,
UpdSrc				char(4),
UpdDt				smalldatetime  /* 46 */
)

grant select on TrancheStruct to Reader
go

