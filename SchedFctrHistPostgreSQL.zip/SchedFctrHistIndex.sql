CREATE UNIQUE INDEX schedfctrhistndx    on schedfctrhist(secid,effdt)
;
