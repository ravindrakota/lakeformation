drop TABLE if exists schedfctrhist
;
CREATE TABLE schedfctrhist (
 secid    int           NOT NULL,
 cusip             char(9)       NOT NULL,
 effdt             date       NOT NULL,
 sched_fctrjan     float      NOT NULL,
 sched_fctrfeb     float      NOT NULL, 
 sched_fctrmar     float      NOT NULL,
 sched_fctrapr     float      NOT NULL,
 sched_fctrmay     float      NOT NULL,
 sched_fctrjun     float      NOT NULL,
 sched_fctrjul     float      NOT NULL, 
 sched_fctraug     float      NOT NULL,
 sched_fctrsep     float      NOT NULL, 
 sched_fctroct     float      NOT NULL, 
 sched_fctrnov     float      NOT NULL,
 sched_fctrdec     float      NOT NULL,
 upddt             timestamp   NOT NULL
)
;
 
grant select, update, insert, delete on embs_owner.schedfctrhist to EMBS_UPDATER_ROLE; 
grant select on embs_owner.schedfctrhist to EMBS_READER_ROLE; 