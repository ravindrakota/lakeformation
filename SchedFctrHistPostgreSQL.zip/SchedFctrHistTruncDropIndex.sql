truncate table embs_owner.schedfctrhist;

DROP INDEX IF EXISTS schedfctrhistndx;

