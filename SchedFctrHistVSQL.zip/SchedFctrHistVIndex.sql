use embshist
go
create unique index SchedFctrHistVNdx     on SchedFctrHistV(SecId,EffDt)
go
