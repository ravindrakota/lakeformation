import java.io.*;

public class convertSchedFctrHist {

  // Converts Hist table from 12 months per record to one month per record

  public static void main (String args[]) throws IOException
  {
    if (args.length != 3) {
      System.out.println("usage: java convertSchedFctrHist inHistFile outHistFile LSEP[LF/CRLF]");
      System.exit(1);
    }
    String inHistFile=args[0];
    String outHistFile=args[1];
    String inLSEP=args[2];
    String LSEP="";
    if (inLSEP.equals("LF"))   LSEP="\n";
    if (inLSEP.equals("CRLF")) LSEP="\r\n";

    String buff = "",outbuff="",outbuffstart="",fld4month="",secid="",delim="|",effdatestart="";
    int startfldnr = 0,inrecs=0,outrecs=0;

    BufferedReader inData = new BufferedReader(new FileReader(inHistFile),8192000);
    BufferedWriter outData= new BufferedWriter(new FileWriter(outHistFile),8192000);
    while ((buff = inData.readLine()) != null) {
       inrecs++;
       secid=getFieldFromDelimStr(buff,1,delim);
       //System.out.println("secid:"+secid);
       if ((inrecs/50000)*50000 == inrecs) System.out.println("Read:"+inrecs+"  Written:"+outrecs);       
             outbuffstart = getMultFieldsFromDelimStr(buff,1,2,delim);
             effdatestart = getFieldFromDelimStr(buff,3,delim).substring(0,4);
             for (int i=1;i<=12;i++) {
                 startfldnr=4+(i-1);  //factor field starts in the fourth field  one field per month
                 fld4month=getFieldFromDelimStr(buff,startfldnr,delim);
                 //skip months with no data
                 if (fld4month.equals("-999.0")) continue;
                 outbuff=outbuffstart
                    +delim+effdatestart+LPad(""+i,2,"0")+"01"
                    +delim+fld4month;
	         outData.write(outbuff+LSEP);
                 outrecs++;
             }
    }
    inData.close();
    outData.close();
    System.out.println("Total Read:"+inrecs+"  Total Written:"+outrecs);
  }


  public static String getFieldFromDelimStr(String inrec, int fieldnum, String delimiter)
  {
    // fields are numbered starting with 1... 
    int delimloc = 0,delimlocprev = 0, ctr=1;
    int delimlength = delimiter.length();
    String returnstr = "";
    delimloc = inrec.indexOf(delimiter);
    if (fieldnum <= 0 ) // fields are numbered starting with 1
      {return "";}
    if (fieldnum > 1 && delimloc < 0) // no delimiter found, return empty
      {return "";}

    for (ctr = 1; ctr < fieldnum ; ctr++)
      {
	if (delimloc < 0) break;
	delimlocprev = delimloc+delimlength;
	delimloc = inrec.indexOf(delimiter,delimlocprev);
      }
    if (ctr < fieldnum) //not enough fields were found, return empty string
      {returnstr  = "";}
    else if (delimlocprev >= 0 && delimloc >0)  // first or middle fields
      {returnstr  = inrec.substring(delimlocprev,delimloc);}
    else if (delimlocprev >= 0 && delimloc < 0) // last field w/ no trailing delimiter
      {returnstr  = inrec.substring(delimlocprev);}
    else if (fieldnum == 1 && delimloc < 0) // first field w/ no delim found
      {returnstr  = inrec;}

    return returnstr;
  }


  //gets multiple sequential fields from a delimited string
  public static String getMultFieldsFromDelimStr(String inrec, int fieldnumstart, int fieldnumend, String delimiter)
  {
    // fields are numbered starting with 1... 
    int delimloc = 0,delimlocprev = 0, startloc=0, endloc=0, ctr=1;
    int delimlength = delimiter.length();
    String returnstr = "",prestr = "", poststr = "";
    delimloc = inrec.indexOf(delimiter);

    if (fieldnumstart <= 0 || fieldnumend <= fieldnumstart) // fields are numbered starting with 1, and ending field number must be > starting
      {return "";}
    if (fieldnumstart > 1 && delimloc < 0) // no delimiter found, return empty
      {return "";}

    for (ctr = 1; ctr < fieldnumstart ; ctr++)
      {
	if (delimloc < 0) break;
	delimlocprev = delimloc+delimlength;
	delimloc = inrec.indexOf(delimiter,delimlocprev);
      }
    if (ctr < fieldnumstart) //not enough fields were found, return empty string
      {returnstr  = "";}

    startloc = delimlocprev; //beginning of string to be returned

    for (ctr = 0; ctr < (fieldnumend-fieldnumstart) ; ctr++)
      {
	if (delimloc < 0) break;
	delimlocprev = delimloc+delimlength;
	delimloc = inrec.indexOf(delimiter,delimlocprev);
      }
    endloc = delimloc;

    if (startloc >= 0 && endloc >0) { // first or middle fields
      returnstr = inrec.substring(startloc,endloc); 
    }
    else if (startloc >= 0 && endloc < 0) { // ending fields w/ no trailing delimiter
      returnstr  = inrec.substring(startloc); 
    }

    return returnstr;
  }

   public static String LPad(String str, int tot_length, String pad_str)
   {
       int i,j;
       j = tot_length - str.length() ; 
       //System.out.println("tot_length - str.length() :" + j );
       for (i = 0; i < j ; i++)
	 { str = pad_str+str;	 }
       return str;
   }




}
