use embshist
go
truncate table SchedFctrHistV
go
drop index SchedFctrHistV.SchedFctrHistVNdx
go
