use embshist
go
drop TABLE SchedFctrHistV
go
CREATE TABLE SchedFctrHistV (
 SecId    	   int           NOT NULL,
 CUSIP             char(9)       NOT NULL,
 EffDt             datetime NOT NULL,
 Sched_Fctr    	   float      NOT NULL
  
)
go
 
grant select on SchedFctrHistV to Reader,Updater
go

use embs
go
create view SchedFctrHistV as select * from embshist..SchedFctrHistV
go
grant select on SchedFctrHistV to Reader, Updater
go
